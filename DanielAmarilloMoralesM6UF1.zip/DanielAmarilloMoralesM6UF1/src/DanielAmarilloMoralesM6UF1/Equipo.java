package DanielAmarilloMoralesM6UF1;

public class Equipo {
	public int equipo;
	public int score;
	public int getEquipo() {
		return equipo;
	}
	public void setEquipo(int equipo) {
		this.equipo = equipo;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public Equipo(int equipo, int score) {
		super();
		this.equipo = equipo;
		this.score = score;
	}
	
}
